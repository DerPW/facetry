// Copyright (c) 2025 OPEN CASCADE SAS
//
// This file is part of Open CASCADE Technology software library.
//
// This library is free software; you can redistribute it and/or modify it under
// the terms of the GNU Lesser General Public License version 2.1 as published
// by the Free Software Foundation, with special exception defined in the file
// OCCT_LGPL_EXCEPTION.txt. Consult the file LICENSE_LGPL_21.txt included in OCCT
// distribution for complete text of the license and disclaimer of any warranty.
//
// Alternatively, this file may be used under the terms of Open CASCADE
// commercial license or contractual agreement.

//! @file IGESData_Array1OfDirPart.hxx
//! @brief Deprecated typedef for backward compatibility.
//! @deprecated This header is deprecated since OCCT 8.0.0.
//!             Use NCollection_Array1<IGESData_DirPart> directly instead.

#ifndef _IGESData_Array1OfDirPart_hxx
#define _IGESData_Array1OfDirPart_hxx

#include <Standard_Macro.hxx>
#include <IGESData_DirPart.hxx>
#include <NCollection_Array1.hxx>

Standard_HEADER_DEPRECATED("IGESData_Array1OfDirPart.hxx is deprecated since OCCT 8.0.0. Use "
                           "NCollection_Array1<IGESData_DirPart> directly.")

  Standard_DEPRECATED(
    "IGESData_Array1OfDirPart is deprecated, use NCollection_Array1<IGESData_DirPart> directly")
typedef NCollection_Array1<IGESData_DirPart> IGESData_Array1OfDirPart;

#endif // _IGESData_Array1OfDirPart_hxx
